#ifndef ESURFINGCLIENT_SIMPROCESS_H
#define ESURFINGCLIENT_SIMPROCESS_H

extern void restart_process();

#endif
